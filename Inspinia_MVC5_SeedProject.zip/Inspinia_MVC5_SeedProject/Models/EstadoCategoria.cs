﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERP_GMEDINA.Models
{
    public class EstadoCategoria
    {
        public const int Activo = 1;//1
        public const int Inactivo = 2;//0
    }

}