﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERP_GMEDINA.Models
{
    public class EstadoSubCategoria
    {
        public const int Activo = 1;

        public const int Inactivo = 2;
    }
}